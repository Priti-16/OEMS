package com.example.pro.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pro.admin.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
    Student findByUsername(String username);
}
