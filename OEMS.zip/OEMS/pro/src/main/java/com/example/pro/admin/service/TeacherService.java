package com.example.pro.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pro.admin.entity.Teacher;
import com.example.pro.admin.repository.TeacherRepository;
@Service
public class TeacherService {
    private final TeacherRepository repo;

    public TeacherService(TeacherRepository repo) {
        this.repo = repo;
    }

    public Teacher addTeacher(Teacher teacher) {
        return repo.save(teacher);
    }
    public boolean login(String username, String password) {
        Teacher t = repo.findByUsername(username);
        return t != null && t.getPassword().equals(password);
    }
    public Teacher save(Teacher teacher) {          // ✅ ADD
        return repo.save(teacher);
    }
    public void deleteById(Long id) {               // ✅ ADD
        repo.deleteById(id);
    }

    public List<Teacher> getAll() {
    return repo.findAll();
}
}