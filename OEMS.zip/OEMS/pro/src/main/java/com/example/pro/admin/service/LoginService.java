package com.example.pro.admin.service;

import org.springframework.stereotype.Service;

import com.example.pro.admin.entity.Student;
import com.example.pro.admin.entity.Teacher;
import com.example.pro.admin.repository.StudentRepository;
import com.example.pro.admin.repository.TeacherRepository;

@Service
public class LoginService {
 private final StudentRepository studentRepo;
 private final TeacherRepository teacherRepo;
    public LoginService(StudentRepository studentRepo,TeacherRepository teacherRepo) {
        this.studentRepo = studentRepo;
        this.teacherRepo= teacherRepo;
    }

    public String login(String username, String password) {
        if (username == null || password == null) {
        return "INVALID";
    }
        // ADMIN
        if (username.equals("admin") && password.equals("admin123")) {
            return "ADMIN";
        }

        // STUDENT
        Student s = studentRepo.findByUsername(username);
        if (s != null && s.getPassword().equals(password)) {
            return "STUDENT";
        }

        Teacher t = teacherRepo.findByUsername(username);
        if(t !=null && t.getPassword().equals(password)){
            return "TEACHER";
        }
        return "INVALID";
    }
    
}
