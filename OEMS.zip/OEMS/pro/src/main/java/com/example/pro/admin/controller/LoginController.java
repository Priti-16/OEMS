package com.example.pro.admin.controller;
import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pro.admin.service.LoginService;
@RestController
@RequestMapping("/api/login")
@CrossOrigin("*")
public class LoginController {
    private final LoginService loginService;
    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping("/login")
public Map<String,String> login(@RequestBody Map<String,String> data) {

    String role = loginService.login(
        data.get("username"),
        data.get("password")
    );

    Map<String,String> res = new HashMap<>();
    res.put("role", role);
    return res;
}
}
