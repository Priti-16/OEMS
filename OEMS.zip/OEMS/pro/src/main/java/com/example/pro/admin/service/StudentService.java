package com.example.pro.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pro.admin.entity.Student;
import com.example.pro.admin.repository.StudentRepository;

@Service
public class StudentService {

    private final StudentRepository repo;

    public StudentService(StudentRepository repo) {
        this.repo = repo;
    }

    public Student addStudent(Student student) {
        return repo.save(student);
    }
    public boolean login(String username, String password) {
        Student s = repo.findByUsername(username);
        return s != null && s.getPassword().equals(password);
    }
    public Student save(Student student) {          // ✅ ADD
        return repo.save(student);
    }

    public void deleteById(Long id) {               // ✅ ADD
        repo.deleteById(id);
    }

    public List<Student> getAll() {
    return repo.findAll();
}
}
