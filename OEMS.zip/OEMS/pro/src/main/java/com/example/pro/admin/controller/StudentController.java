package com.example.pro.admin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pro.admin.entity.Student;
import com.example.pro.admin.service.StudentService;

@RestController
@RequestMapping("/api/admin/student")
@CrossOrigin("*")
public class StudentController {
private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @PostMapping("/add")
    public Student addStudent(@RequestBody Student student) {
        return service.addStudent(student);
    }
     @PostMapping("/login")
    public String login(@RequestBody Map<String,String> data) {
        boolean ok = service.login(data.get("username"), data.get("password"));
        return ok ? "success" : "failed";
    }
    @GetMapping("/all")
    public List<Student> getAllStudents() {
    return service.getAll();
}
    @PutMapping("/update/{id}")
    public Student updateStudent(@PathVariable Long id, @RequestBody Student student) {
        student.setId(id);
        return service.save(student);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteExam(@PathVariable Long id) {
        service.deleteById(id);
}
}
