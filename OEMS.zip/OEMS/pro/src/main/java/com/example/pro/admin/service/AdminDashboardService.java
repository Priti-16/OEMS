package com.example.pro.admin.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.pro.admin.repository.ExamRepository;
import com.example.pro.admin.repository.StudentRepository;
import com.example.pro.admin.repository.TeacherRepository;
@Service
public class AdminDashboardService {
    private final StudentRepository studentRepo;
    private final TeacherRepository teacherRepo;
    private final ExamRepository examRepo;

    public AdminDashboardService(StudentRepository studentRepo,
                                 TeacherRepository teacherRepo,
                                 ExamRepository examRepo) {
        this.studentRepo = studentRepo;
        this.teacherRepo = teacherRepo;
        this.examRepo = examRepo;
    }

    public Map<String, Long> getDashboardCounts() {
        Map<String, Long> data = new HashMap<>();
        data.put("students", studentRepo.count());
        data.put("teachers", teacherRepo.count());
        data.put("exams", examRepo.count());
        return data;
    }
}
