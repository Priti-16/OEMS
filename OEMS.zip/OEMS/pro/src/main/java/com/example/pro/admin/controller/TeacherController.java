package com.example.pro.admin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pro.admin.entity.Teacher;
import com.example.pro.admin.service.TeacherService;

@RestController
@RequestMapping("/api/admin/teacher")
@CrossOrigin("*")
public class TeacherController {

    private final TeacherService service;

    public TeacherController(TeacherService service) {
        this.service = service;
    }

    @PostMapping("/add")
    public Teacher addTeacher(@RequestBody Teacher teacher) {
        return service.addTeacher(teacher);
    }
    @PostMapping("/login")
    public String login(@RequestBody Map<String,String> data) {
        boolean ok = service.login(data.get("username"), data.get("password"));
        return ok ? "success" : "failed";
    }
    @GetMapping("/all")
    public List<Teacher> getAllTeacher() {
    return service.getAll();
}
    @PutMapping("/update/{id}")
    public Teacher updateTeacher(@PathVariable Long id, @RequestBody Teacher teacher) {
        teacher.setId(id);
        return service.save(teacher);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteExam(@PathVariable Long id) {
        service.deleteById(id);
}
}
