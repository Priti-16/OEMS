package com.example.pro.admin.service;

import org.springframework.stereotype.Service;

import com.example.pro.admin.entity.Exam;
import com.example.pro.admin.entity.Student;
import com.example.pro.admin.entity.Teacher;
import com.example.pro.admin.repository.ExamRepository;
import com.example.pro.admin.repository.StudentRepository;
import com.example.pro.admin.repository.TeacherRepository;

@Service
public class AdminManageService {

    private final StudentRepository studentRepo;
    private final TeacherRepository teacherRepo;
    private final ExamRepository examRepo;

    public AdminManageService(StudentRepository studentRepo,
                              TeacherRepository teacherRepo,
                              ExamRepository examRepo) {
        this.studentRepo = studentRepo;
        this.teacherRepo = teacherRepo;
        this.examRepo = examRepo;
    }
    
    public Student addStudent(Student student) {
        return studentRepo.save(student);
    }

    public Teacher addTeacher(Teacher teacher) {
        return teacherRepo.save(teacher);
    }

    public Exam addExam(Exam exam) {
        return examRepo.save(exam);
    }
}
