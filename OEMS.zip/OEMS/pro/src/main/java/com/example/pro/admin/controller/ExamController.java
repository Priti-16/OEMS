package com.example.pro.admin.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pro.admin.entity.Exam;
import com.example.pro.admin.repository.ExamRepository;

@RestController
@RequestMapping("/api/admin/exam")
@CrossOrigin("*")
public class ExamController {

    private final ExamRepository examRepo;

    public ExamController(ExamRepository examRepo) {
        this.examRepo = examRepo;
    }

    // Teacher adds exam
    @PostMapping("/add")
    public Exam addExam(@RequestBody Exam exam) {
        return examRepo.save(exam);
    }

    // Student views exams
    @GetMapping("/all")
    public List<Exam> getAllExams() {
        return examRepo.findAll();
    }
    @PutMapping("/update/{id}")
    public Exam updateExam(@PathVariable Long id, @RequestBody Exam exam) {
        exam.setId(id);
        return examRepo.save(exam);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteExam(@PathVariable Long id) {
        examRepo.deleteById(id);
    }
}
