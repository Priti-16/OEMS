package com.example.pro.admin.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "exams")
public class Exam {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String examName;
    private String date;

    // getters & setters
    public Long getId() { return id; }
    public String getExamName() { return examName; }
    public String getDate() { return date; }

    public void setExamName(String examName) { this.examName = examName; }
    public void setDate(String date) { this.date = date; }

    public void setId(Long id) {
        this.id = id;
    }
}
