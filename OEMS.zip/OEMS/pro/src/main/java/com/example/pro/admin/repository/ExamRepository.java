package com.example.pro.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pro.admin.entity.Exam;

public interface ExamRepository extends JpaRepository<Exam, Long> {
    
}
