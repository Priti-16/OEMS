// package com.example.pro.admin.controller;

// import org.springframework.web.bind.annotation.CrossOrigin;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// import com.example.pro.admin.entity.Exam;
// import com.example.pro.admin.entity.Student;
// import com.example.pro.admin.entity.Teacher;
// import com.example.pro.admin.service.AdminManageService;

// @RestController
// @RequestMapping("/api/admin")
// @CrossOrigin("*")
// public class AdminManageController {

//     private final AdminManageService manageService;

//     public AdminManageController(AdminManageService manageService) {
//         this.manageService = manageService;
//     }

//     @PostMapping("/add-student")
//     public Student addStudent(@RequestBody Student student) {
//         return manageService.addStudent(student);
//     }

//     @PostMapping("/add-teacher")
//     public Teacher addTeacher(@RequestBody Teacher teacher) {
//         return manageService.addTeacher(teacher);
//     }

//     @PostMapping("/add-exam")
//     public Exam addExam(@RequestBody Exam exam) {
//         return manageService.addExam(exam);
//     }
// }
